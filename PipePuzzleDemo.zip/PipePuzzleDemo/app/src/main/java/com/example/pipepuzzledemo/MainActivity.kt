package com.example.pipepuzzledemo

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlin.math.abs

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { App() }
    }
}

private enum class TileType { Empty, Block, Straight, Elbow, Tee, Source, Sink }

// 4-bit mask: N=1 E=2 S=4 W=8
private const val N = 1
private const val E = 2
private const val S = 4
private const val W = 8

private fun rotateMask(mask: Int, rot: Int): Int {
    var m = mask
    repeat((rot % 4 + 4) % 4) {
        val n = (m and N) != 0
        val e = (m and E) != 0
        val s = (m and S) != 0
        val w = (m and W) != 0
        m = 0
        if (w) m = m or N
        if (n) m = m or E
        if (e) m = m or S
        if (s) m = m or W
    }
    return m
}

private fun baseMask(type: TileType): Int = when (type) {
    TileType.Straight -> N or S
    TileType.Elbow -> N or E
    TileType.Tee -> N or E or S
    TileType.Source -> E
    TileType.Sink -> W
    else -> 0
}

private data class Tile(
    val type: TileType,
    val fixed: Boolean = false,
    val rot: Int = 0
) {
    fun openMask(): Int = rotateMask(baseMask(type), rot)
    fun rotated(): Tile = if (fixed || type == TileType.Block || type == TileType.Empty) this else copy(rot = (rot + 1) % 4)
}

private data class Level(
    val w: Int,
    val h: Int,
    val tiles: List<Tile>
)

private fun demoLevel(): Level {
    // A small, solvable 6x6 demo with 1 source + 2 sinks and some decoys.
    // NOTE: "no leaks" applies globally.
    val w = 6
    val h = 6
    fun idx(x: Int, y: Int) = y * w + x
    val t = MutableList(w * h) { Tile(TileType.Empty) }

    // Blocks border corners a bit for shape
    t[idx(2, 0)] = Tile(TileType.Block)
    t[idx(3, 0)] = Tile(TileType.Block)
    t[idx(2, 5)] = Tile(TileType.Block)
    t[idx(3, 5)] = Tile(TileType.Block)

    // Source and sinks
    t[idx(0, 2)] = Tile(TileType.Source, fixed = true, rot = 0) // points East
    t[idx(5, 1)] = Tile(TileType.Sink, fixed = true, rot = 0)   // expects West
    t[idx(5, 4)] = Tile(TileType.Sink, fixed = true, rot = 0)   // expects West

    // Main trunk
    t[idx(1, 2)] = Tile(TileType.Straight, rot = 1) // horizontal
    t[idx(2, 2)] = Tile(TileType.Tee, rot = 1)      // E,S,W (after rot)
    t[idx(3, 2)] = Tile(TileType.Straight, rot = 1) // horizontal
    t[idx(4, 2)] = Tile(TileType.Elbow, rot = 2)    // S,W (after rot)
    t[idx(4, 3)] = Tile(TileType.Straight, rot = 0) // vertical
    t[idx(4, 4)] = Tile(TileType.Elbow, rot = 3)    // N,W (after rot)
    t[idx(3, 4)] = Tile(TileType.Straight, rot = 1) // horizontal
    t[idx(2, 4)] = Tile(TileType.Straight, rot = 1) // horizontal
    t[idx(1, 4)] = Tile(TileType.Elbow, rot = 0)    // N,E (after rot)
    t[idx(1, 3)] = Tile(TileType.Straight, rot = 0) // vertical
    t[idx(1, 1)] = Tile(TileType.Elbow, rot = 1)    // E,S (after rot)
    t[idx(2, 1)] = Tile(TileType.Straight, rot = 1) // horizontal
    t[idx(3, 1)] = Tile(TileType.Straight, rot = 1) // horizontal
    t[idx(4, 1)] = Tile(TileType.Straight, rot = 1) // horizontal to sink at (5,1)

    // Branch down from the T at (2,2)
    t[idx(2, 3)] = Tile(TileType.Straight, rot = 0) // vertical
    t[idx(2, 4)] = Tile(TileType.Straight, rot = 1) // already set
    t[idx(5, 4-0)] = t[idx(5, 4-0)] // keep

    // Connect to sink at (5,4)
    t[idx(4, 4)] = t[idx(4, 4)] // already
    t[idx(5, 4)] = t[idx(5, 4)] // sink

    // Decoy island that must be sealed (no leaks!), solvable by rotating into a loop
    t[idx(0, 0)] = Tile(TileType.Elbow, rot = 1)
    t[idx(1, 0)] = Tile(TileType.Elbow, rot = 2)
    t[idx(0, 1)] = Tile(TileType.Elbow, rot = 0)
    t[idx(1, 1)] = t[idx(1, 1)].copy(fixed = false) // part of main; keep rot
    // We'll add a small 2x2 loop in top-left using (0,0)(1,0)(0,1)(1,1) but (1,1) is in main path.
    // So instead make decoy at bottom-left:
    t[idx(0, 5)] = Tile(TileType.Elbow, rot = 0)
    t[idx(0, 4)] = Tile(TileType.Elbow, rot = 1)
    t[idx(1, 5)] = Tile(TileType.Elbow, rot = 3)
    t[idx(1, 4)] = t[idx(1, 4)] // in main; ok—player can solve by rotating the three elbows into a closed loop around the main elbow at (1,4)

    return Level(w, h, t)
}

private data class EvalResult(
    val powered: BooleanArray,
    val leaks: List<Pair<Int, Int>>,
    val win: Boolean
)

private fun eval(level: Level): EvalResult {
    val w = level.w
    val h = level.h
    val tiles = level.tiles

    fun inBounds(x: Int, y: Int) = x in 0 until w && y in 0 until h
    fun idx(x: Int, y: Int) = y * w + x

    fun neighbor(x: Int, y: Int, dirBit: Int): Pair<Int, Int> = when (dirBit) {
        N -> x to (y - 1)
        E -> (x + 1) to y
        S -> x to (y + 1)
        W -> (x - 1) to y
        else -> x to y
    }
    fun opposite(dirBit: Int): Int = when (dirBit) {
        N -> S
        E -> W
        S -> N
        W -> E
        else -> 0
    }

    val leaks = mutableListOf<Pair<Int, Int>>() // store (tileIndex, dirBit) for display

    // Leak check: any open side without matching neighbor open side is a leak.
    for (y in 0 until h) for (x in 0 until w) {
        val t = tiles[idx(x, y)]
        if (t.type == TileType.Block || t.type == TileType.Empty) continue
        val mask = t.openMask()
        for (dir in listOf(N, E, S, W)) {
            if ((mask and dir) == 0) continue
            val (nx, ny) = neighbor(x, y, dir)
            if (!inBounds(nx, ny)) {
                leaks.add(idx(x, y) to dir)
                continue
            }
            val nt = tiles[idx(nx, ny)]
            val nmask = nt.openMask()
            if (nt.type == TileType.Block || nt.type == TileType.Empty || (nmask and opposite(dir)) == 0) {
                leaks.add(idx(x, y) to dir)
            }
        }
    }

    val powered = BooleanArray(w * h) { false }
    val sourceIndices = tiles.indices.filter { tiles[it].type == TileType.Source }
    val sinkIndices = tiles.indices.filter { tiles[it].type == TileType.Sink }

    // If leaks exist, we still compute powered (for nicer feedback), but win will be false.
    // BFS from all sources.
    val queue = ArrayDeque<Int>()
    for (s in sourceIndices) {
        powered[s] = true
        queue.add(s)
    }

    fun coord(i: Int) = (i % w) to (i / w)

    while (queue.isNotEmpty()) {
        val i = queue.removeFirst()
        val (x, y) = coord(i)
        val t = tiles[i]
        val mask = t.openMask()
        for (dir in listOf(N, E, S, W)) {
            if ((mask and dir) == 0) continue
            val (nx, ny) = neighbor(x, y, dir)
            if (!inBounds(nx, ny)) continue
            val ni = idx(nx, ny)
            val nt = tiles[ni]
            if (nt.type == TileType.Block || nt.type == TileType.Empty) continue
            val nmask = nt.openMask()
            if ((nmask and opposite(dir)) == 0) continue
            if (!powered[ni]) {
                powered[ni] = true
                queue.add(ni)
            }
        }
    }

    val allSinksPowered = sinkIndices.all { powered[it] }
    val win = leaks.isEmpty() && sourceIndices.isNotEmpty() && sinkIndices.isNotEmpty() && allSinksPowered

    return EvalResult(powered = powered, leaks = leaks, win = win)
}

private fun tileGlyph(type: TileType, rot: Int): String = when (type) {
    TileType.Block -> "■"
    TileType.Empty -> " "
    TileType.Source -> "▶"
    TileType.Sink -> "◀"
    TileType.Straight -> if (rot % 2 == 0) "┃" else "━"
    TileType.Elbow -> when (rot % 4) {
        0 -> "┗" // N+E base rotated
        1 -> "┏"
        2 -> "┓"
        else -> "┛"
    }
    TileType.Tee -> when (rot % 4) {
        0 -> "┳"
        1 -> "┣"
        2 -> "┻"
        else -> "┫"
    }
}

@Composable
private fun App() {
    MaterialTheme {
        val level = remember { demoLevel() }
        var tiles by remember { mutableStateOf(level.tiles) }
        var moves by remember { mutableIntStateOf(0) }

        val evalResult by remember(tiles) {
            mutableStateOf(eval(level.copy(tiles = tiles)))
        }

        val w = level.w
        val h = level.h

        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text("Pipe Puzzle Demo") }
                )
            }
        ) { padding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Moves: $moves", style = MaterialTheme.typography.titleMedium)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = {
                            tiles = level.tiles
                            moves = 0
                        }) { Text("Restart") }
                    }
                }

                if (evalResult.win) {
                    Card(
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(Modifier.padding(12.dp)) {
                            Text("Solved!", fontWeight = FontWeight.Bold)
                            Text("No leaks and all sinks powered.")
                        }
                    }
                } else if (evalResult.leaks.isNotEmpty()) {
                    Text(
                        "Leaks: ${evalResult.leaks.size} (rotate tiles to seal all open ends)",
                        color = MaterialTheme.colorScheme.error
                    )
                } else {
                    Text("Seal all pipes and power every sink.")
                }

                // Grid
                LazyVerticalGrid(
                    columns = GridCells.Fixed(w),
                    verticalArrangement = Arrangement.spacedBy(6.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    itemsIndexed(tiles) { i, tile ->
                        val powered = evalResult.powered[i]
                        val bg = if (powered) MaterialTheme.colorScheme.secondaryContainer
                        else MaterialTheme.colorScheme.surfaceVariant

                        Surface(
                            tonalElevation = 1.dp,
                            shadowElevation = 1.dp,
                            shape = MaterialTheme.shapes.small,
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                            modifier = Modifier
                                .aspectRatio(1f)
                                .clickable {
                                    val t = tiles[i]
                                    val nt = t.rotated()
                                    if (nt != t) {
                                        tiles = tiles.toMutableList().also { it[i] = nt }
                                        moves += 1
                                    }
                                }
                        ) {
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .background(bg),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    tileGlyph(tile.type, tile.rot),
                                    style = MaterialTheme.typography.headlineMedium
                                )
                            }
                        }
                    }
                }

                Text(
                    "Tip: In this demo, even “extra” pipes must be sealed. " +
                            "Rotate any leaking piece into a closed loop or remove open ends.",
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }
    }
}
